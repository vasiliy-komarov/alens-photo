export default function printMe(msg) {
    console.log('Updating printsss.js...', msg);
    console.log('Updating printsss.js...', msg);
}