import css from '../styles/main.css';
import calendar from './images/calendar.png'
import printMe from './print/print'
import '../styles/chunk.css';

function component() {
    let element = document.createElement('div');

    element.innerHTML = `${new Date()} Hello webpack ${css.body}`;
    element.classList.add(css.hello);

    var myIcon = new Image();
    myIcon.src = calendar;
    element.appendChild(myIcon);
    printMe('hello');
    printMe('world');
    return element;
}

document.body.appendChild(component());

if (module.hot) {
    module.hot.accept('./print/print.js', function () {
        console.log('Accepting the updated printMe module!');
        printMe();
    })
}